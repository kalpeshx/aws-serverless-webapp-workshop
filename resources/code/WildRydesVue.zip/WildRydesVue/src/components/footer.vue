<template>
   <footer class="site-footer">
    <div class="row column">
      <nav class="footer-nav">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="unicorns">Meet the Unicorns</a></li>
          <li><a href="investors">Investors & Board of Directors</a></li>
          <li><a href="faq">FAQ</a></li>
          <li><a href="apply">Apply</a></li>
        </ul>
      </nav>
    </div>
    <div class="row column">
      <div class="footer-legal">
        &copy;WildRydes Inc<br>
        All Rights Reserved
      </div>
    </div>
  </footer>
</template>
