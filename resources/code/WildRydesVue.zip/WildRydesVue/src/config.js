// Add your API invoke URL below, configured in Module 3. 

module.exports = {
    api: {
        invokeUrl: '' // e.g. https://rc2345678345.execute-api.us-west-2.amazonaws.com/prod,
    }
}
